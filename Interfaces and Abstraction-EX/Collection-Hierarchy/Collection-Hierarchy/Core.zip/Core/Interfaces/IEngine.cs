﻿namespace Collection_Hierarchy.Core.Interfaces
{
    public interface IEngine
    {
        public void Run();

    }
}

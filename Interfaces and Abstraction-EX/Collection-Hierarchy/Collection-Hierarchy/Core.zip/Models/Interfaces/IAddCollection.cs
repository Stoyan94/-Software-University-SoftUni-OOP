﻿namespace Collection_Hierarchy.Models.Interfaces
{
    public interface IAddCollection
    {
        int Add(string item);
    }
}

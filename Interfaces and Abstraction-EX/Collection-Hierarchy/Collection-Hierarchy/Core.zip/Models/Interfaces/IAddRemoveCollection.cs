﻿namespace Collection_Hierarchy.Models.Interfaces
{
    public interface IAddRemoveCollection : IAddCollection
    {
        string Remove();
    }
}

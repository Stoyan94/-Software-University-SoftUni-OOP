﻿using Collection_Hierarchy.Core;
using Collection_Hierarchy.Core.Interfaces;

IEngine engine = new Engine();

engine.Run();
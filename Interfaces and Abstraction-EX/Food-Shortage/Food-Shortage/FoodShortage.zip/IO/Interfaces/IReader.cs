﻿using System;

namespace Food_Shortage.IO.Interfaces
{
    public interface IReader
    {
       string ReadLine();
    }
}

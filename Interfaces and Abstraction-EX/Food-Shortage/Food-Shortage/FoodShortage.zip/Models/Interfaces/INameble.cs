﻿namespace Food_Shortage.Models.Interfaces
{
    public interface INameble
    {
        public string Name { get;}

        public int Age { get;}
    }
}

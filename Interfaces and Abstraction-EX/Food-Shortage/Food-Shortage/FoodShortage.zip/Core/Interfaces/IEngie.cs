﻿namespace Food_Shortage.Core.Interfaces
{
    public interface IEngie
    {
        void Run();
    }
}

﻿using Food_Shortage.Core;
using Food_Shortage.Core.Interfaces;
using Food_Shortage.IO;
using System;

IEngie engie = new Engine(new ConsoleReader(), new ConsoleWriter());

engie.Run();
﻿namespace MilitaryElite.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}

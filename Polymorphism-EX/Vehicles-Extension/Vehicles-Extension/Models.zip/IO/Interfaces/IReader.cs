﻿namespace Vehicles_Extension.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}

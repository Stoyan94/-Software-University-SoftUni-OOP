﻿namespace Vehicles_Extension.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}

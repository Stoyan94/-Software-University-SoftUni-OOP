﻿namespace Wild_Farm.Models.Interfaces
{
    public interface IFeline : IMammal
    {
        string Breed { get;}
    }
}

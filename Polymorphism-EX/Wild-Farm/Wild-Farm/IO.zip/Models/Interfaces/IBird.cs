﻿namespace Wild_Farm.Models.Interfaces
{
    public interface IBird : IAnimal
    {
        double WingSize { get; }

    }
}

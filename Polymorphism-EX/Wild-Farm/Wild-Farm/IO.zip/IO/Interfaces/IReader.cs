﻿namespace Wild_Farm.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}

﻿using Wild_Farm.Models.Interfaces;

namespace Wild_Farm.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(object obj);
    }
}

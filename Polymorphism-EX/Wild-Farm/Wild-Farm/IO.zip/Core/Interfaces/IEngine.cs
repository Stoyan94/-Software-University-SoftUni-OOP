﻿namespace Wild_Farm.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
